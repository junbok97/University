//
//  AlbumDetailViewController.swift
//  ch13-albumWithMemo
//
//  Created by iOSprogramming on 2022/02/09.
//

import UIKit

class AlbumDetailViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var memoTextView: UITextView!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var bottomStackViewConstraint: NSLayoutConstraint!
    
    var image: UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageView.image = image ?? nil  // nil인 경우는 위의 didSet가 imageView가 생성되기 후에 호출된 경우
   }
}

