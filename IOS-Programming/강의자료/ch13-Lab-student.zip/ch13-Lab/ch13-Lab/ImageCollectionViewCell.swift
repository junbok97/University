//
//  ImageCollectionViewCell.swift
//  ch13-albumWithMemo
//
//  Created by iOSprogramming on 2022/02/09.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
