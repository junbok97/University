//
//  ViewController.swift
//  ch13-albumWithMemo
//
//  Created by iOSprogramming on 2022/02/09.
//

import UIKit
import Photos

class AlbumViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    
    
    var fetchResult: PHFetchResult<PHAsset>!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "앨범관리"
        
        let allPhotosOptions = PHFetchOptions()
        allPhotosOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
        fetchResult = PHAsset.fetchAssets(with: allPhotosOptions) // 모든 사진의 목록을 갖는다

        collectionView.reloadData()
        
        
        collectionView.delegate = self
        collectionView.dataSource = self
    }

}

extension AlbumViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // 사진의 갯수를 리턴한다.
        return fetchResult == nil ? 0: fetchResult.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCollectionViewCell", for:  indexPath) as! ImageCollectionViewCell

        let asset = fetchResult.object(at: indexPath.row)  // 이미지에 대한 메타 데이터를 가져온다
        PHCachingImageManager.default().requestImage(for: asset, targetSize: CGSize(), contentMode: .aspectFill, options: nil){
            (image, _) in    // 요청한 이미지를 디스크로부터 읽으면 이 함수가 호출 된다.
            cell.imageView.image = image  // 여기서 이미지를 보이게 한다
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // 이 이미지를 클릭하면 자세히 보기로 전이한다. Send가 self가 아니고 클릭된 Cell의 indexPath이다.
        performSegue(withIdentifier: "ShowDetail", sender: indexPath)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        // CollectionView에 하나의 이미지의 크기를 리턴한다.
        // indexPath에 따라 크리를 조정하는 것도 가능하다.
       return CGSize(width: 90, height: 90)
    }

}

extension AlbumViewController{
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let albumDetailViewController = segue.destination as! AlbumDetailViewController

        // 이미지에 대한 정보를 가져온다
        let indexPath = sender as! IndexPath    // sender이 indexPath이다.
        let asset = fetchResult.object(at: indexPath.row)
 
        let options = PHImageRequestOptions()
        options.deliveryMode = .highQualityFormat // 고해상도를 가져오기 우l함임
        PHCachingImageManager.default().requestImage(for: asset, targetSize: CGSize(), contentMode: .aspectFill, options: options, resultHandler: { image, _ in
            // 한참있다가 실행된다. 즉, albumDetailViewController가 로딩되고 appear한 후에 나타난다.
            albumDetailViewController.image = image  

        })
    }
}


