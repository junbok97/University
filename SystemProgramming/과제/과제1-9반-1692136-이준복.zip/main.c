//***************************************************************
//                   HEADER FILE USED IN PROJECT
//***************************************************************

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

//***************************************************************
//                   STURUCTURE USED IN PROJECT
//****************************************************************

struct student
{
	int rollno;
	char name[50];
	int p_marks, c_marks;
	double per;
	char grade;
}st;

//***************************************************************
//        global declaration
//****************************************************************

FILE* fptr;
int fd;


//***************************************************************
//        function to write in file
//****************************************************************

void write_student()
{

	if((fd = open("student.dat", O_WRONLY | O_APPEND | O_CREAT, 0644)) == -1){
		printf("write_student() open error\n");
		exit(0);
	}

		
	printf("\nPlease Enter The New Details of student \n");
	printf("\nEnter The roll number of student ");
	scanf("%d", &st.rollno);		
	getchar();
	printf("\n\nEnter The Name of student ");	
	fgets(st.name,sizeof(st.name),stdin);
	st.name[strlen(st.name)-1] = '\0'; // ��������
	printf("\nEnter The marks in physics out of 100 : ");
	scanf("%d", &st.p_marks);
	printf("\nEnter The marks in chemistry out of 100 : ");	
	scanf("%d", &st.c_marks);

	st.per = (st.p_marks + st.c_marks) / 2.0;
	if (st.per >= 60)
		st.grade = 'A';
	else if (st.per >= 50 && st.per < 60)
		st.grade = 'B';
	else if (st.per >= 33 && st.per < 50)
		st.grade = 'C';
	else
		st.grade = 'F';

	if (write(fd, &st, sizeof(st)) != sizeof(st)) {
		printf("wirte stduent write error\n");
	}
	close(fd);


	
	printf("\n\nStudent Record Has Been Created.  Press any key.... ");
	while(getchar() != '\n');
	getchar();
}


//***************************************************************
//        function to read all records from file
//****************************************************************


void display_all()
{

	system("clear");
	printf("\n\n\n\t\tDISPLAY ALL RECORD !!!\n\n");
	printf("====================================================\n");
	printf("R.No.   Name       P   C   Avg   Grade\n");
	printf("====================================================\n");

	fd = open("student.dat", O_RDONLY);
	
	
		

	
	while (read(fd, &st, sizeof(st)) > 0) {
		printf("%-7d %-10s %-3d %-3d %-3.2f  %-1c\n",
			st.rollno, st.name, st.p_marks, st.c_marks, st.per, st.grade);
	}
	close(fd);
	
	while(getchar() != '\n');
	getchar();

}


//***************************************************************
//        function to read specific record from file
//****************************************************************


void display_sp(int n)
{
	int flag = 0;

	if ((fd = open("student.dat", O_RDONLY)) == -1) {
		printf("display_sp open error\n");
		exit(0);
	}


	while (read(fd, &st, sizeof(st)) > 0)
	{
		if (st.rollno == n)
		{
			system("clear");
			printf("\nRoll number of student : %d", st.rollno);
			printf("\nName of student : %s", st.name);
			printf("\nMarks in Physics : %d", st.p_marks);
			printf("\nMarks in Chemistry : %d", st.c_marks);
			printf("\nPercentage of student is  : %.2f", st.per);
			printf("\nGrade of student is : %c", st.grade);
			flag = 1;
		}
	}
	close(fd);
	if (flag == 0)
		printf("\n\nrecord not exist");
	
	while(getchar() != '\n');
	getchar();
}


//***************************************************************
//        function to modify record of file
//****************************************************************


void modify_student()
{
	int no, found = 0, i;
	
	system("clear");
	printf("\n\n\tTo Modify ");
	printf("\n\n\tPlease Enter The roll number of student ");
	scanf("%d", &no);

	if ((fd = open("student.dat", O_RDWR)) == -1) {
		printf("modeify_student open error\n");
		exit(0);
	}
	

	while ((i = read(fd, &st, sizeof(st))) > 0 && found == 0)
	{
		if (st.rollno == no)
		{
			printf("\nRoll number of student : %d", st.rollno);
			printf("\nName of student : %s", st.name);
			printf("\nMarks in Physics : %d", st.p_marks);
			printf("\nMarks in Chemistry : %d", st.c_marks);
			printf("\nPercentage of student is  : %.2f", st.per);
			printf("\nGrade of student is : %c", st.grade);
			printf("\nPlease Enter The New Details of student \n");
			printf("\nEnter The roll number of student ");
			scanf("%d", &st.rollno);
			getchar();  //flushing buffer (fflsh�� �۵�����)
			printf("\n\nEnter The Name of student ");
			fgets(st.name,sizeof(st.name),stdin);
			st.name[strlen(st.name)-1]='\0'; // ���� ����
			printf("\nEnter The marks in physics out of 100 : ");
			scanf("%d", &st.p_marks);
			printf("\nEnter The marks in chemistry out of 100 : ");
			scanf("%d", &st.c_marks);

			st.per = (st.p_marks + st.c_marks) / 2.0;
			if (st.per >= 60)
				st.grade = 'A';
			else if (st.per >= 50 && st.per < 60)
				st.grade = 'B';
			else if (st.per >= 33 && st.per < 50)
				st.grade = 'C';
			else
				st.grade = 'F';


			
			lseek(fd, -sizeof(st), SEEK_CUR);
			
			write(fd, &st, sizeof(st));

			printf("\n\n\t Record Updated");

			found = 1;
			break;
		}
	}

	close(fd);
	if (found == 0)
		printf("\n\n Record Not Found ");
	while(getchar() != '\n');
	getchar();
}


//***************************************************************
//        function to delete record of file
//****************************************************************


void delete_student()
{
	int no, fd2;

	system("clear");
	printf("\n\n\n\tDelete Record");
	printf("\n\nPlease Enter The roll number of student You Want To Delete ");
	scanf("%d", &no);


	if ((fd = open("student.dat", O_RDONLY)) == -1) {
		printf("modeify_student fd open error\n");
		exit(0);
	}
	if ((fd2 = open("temp.dat", O_WRONLY|O_CREAT|O_TRUNC,0644)) == -1) {
		printf("delete_student fd2 open error\n");
		exit(0);
	}

	lseek(fd,0,SEEK_SET);



	while (read(fd, &st, sizeof(st)) > 0)
	{
		if (st.rollno != no)
		{
			write(fd2, &st, sizeof(st));
		}
	}
	close(fd);
	close(fd2);
	remove("student.dat");
	rename("temp.dat", "student.dat");
	printf("\n\n\tRecord Deleted ..");
	while(getchar() != '\n');
	getchar();
}



//***************************************************************
//        THE MAIN FUNCTION OF PROGRAM
//****************************************************************
void main()
{
	char ch;
	int num;
	do
	{
		system("clear");

		printf("\n\n\t1.CREATE STUDENT RECORD");
		printf("\n\n\t2.DISPLAY ALL STUDENTS RECORDS");
		printf("\n\n\t3.SEARCH STUDENT RECORD ");
		printf("\n\n\t4.MODIFY STUDENT RECORD");
		printf("\n\n\t5.DELETE STUDENT RECORD");
		printf("\n\n\t6.EXIT");
		printf("\n\n\tPlease Enter Your Choice (1-6) ");
		rewind(stdin);
		ch = getchar();

		switch (ch)
		{
		case '1':	system("clear");
			write_student();
			break;
		case '2':	display_all();
			break;
		case '3':	system("clear");
			printf("\n\n\tPlease Enter The roll number ");
			scanf("%d", &num);
			display_sp(num);
			break;
		case '4':	modify_student(); break;
		case '5':	delete_student(); break;
		case '6':	break;
		default:	printf("\a");
		}
	} while (ch != '6');
}
//***************************************************************
//                END OF PROJECT
//***************************************************************
